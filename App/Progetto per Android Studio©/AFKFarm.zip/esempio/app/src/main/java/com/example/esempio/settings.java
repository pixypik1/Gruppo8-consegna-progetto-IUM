package com.example.esempio;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.esempio.R.id;
import com.example.esempio.R.layout;

import java.nio.charset.CharacterCodingException;

import static android.R.layout.*;

public class settings extends AppCompatActivity implements AdapterView.OnItemSelectedListener{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layout.activity_settings);

        //spinner
        Spinner languageSpinner = findViewById(id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.numbers, simple_spinner_item);
        adapter.setDropDownViewResource(simple_spinner_dropdown_item);
        languageSpinner.setAdapter(adapter);
        languageSpinner.setOnItemSelectedListener(this);


        // link profilo

        TextView aa = findViewById(R.id.profileView);

        aa.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                openHelp();
            }
        });

        //immagine "indietro"
        ImageView imageView = (ImageView) findViewById(id.returnImage);
        imageView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v)
            {
                onBackPressed();
            }
        });

    }



    public void openHelp(){
        Intent intent = new Intent(this, help.class);
        startActivity(intent);
    }

    //metodi per lo spinner
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String text = parent.getItemAtPosition(position).toString();

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

        String text = parent.getItemAtPosition(0).toString();

    }
}