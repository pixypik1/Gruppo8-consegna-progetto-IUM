package com.example.esempio;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.bluetooth.BluetoothDevice;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.media.Image;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.ShareActionProvider;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class monitoring extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_monitoring);

        //immagine "indietro"
        ImageView imageView = (ImageView) findViewById(R.id.returnImage);
        imageView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v)
            {
                openHome();
            }
        });

        ImageView settingsIMG = (ImageView) findViewById(R.id.settingsImage);
        settingsIMG.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v)
            {
                openSettings();
            }
        });

        Button newB = (Button) findViewById(R.id.newButton);
        Button noB = (Button) findViewById(R.id.cancButton);

        Button dispB = (Button) findViewById(R.id.dispBtn);


        //bottone nuovo campo
        newB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog dialog;
                AlertDialog.Builder builder = new AlertDialog.Builder(monitoring.this);
                final EditText input1 = new EditText(monitoring.this);



                TextView mess1= new TextView(monitoring.this);

                mess1.setTextSize(18);
                mess1.setText("  Nome del campo: ");

                LinearLayout layout = new LinearLayout(monitoring.this);
                layout.setOrientation(LinearLayout.VERTICAL);

                layout.addView(mess1);
                layout.addView(input1);


                builder.setTitle("Nuovo Campo");
                builder.setMessage("");
                builder.setView(layout);


                builder.setPositiveButton("Aggiungi", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {



                        TextView text1 = findViewById(R.id.nomeCampo);
                        text1.setText(input1.getText().toString());

                        ImageView image = (ImageView) findViewById(R.id.campIMG);
                        image.setImageResource(R.drawable.noimage);

                        ImageView tempimg = (ImageView) findViewById(R.id.tempImg);
                        tempimg.setImageResource(R.drawable.empty);

                        TextView temp = findViewById(R.id.temperatura);
                        temp.setText("Temperatura : Elaborazione..");

                        TextView umidity = findViewById(R.id.umidità);
                        umidity.setText("Umidità : Elaborazione..");

                        TextView lux  = findViewById(R.id.luce);
                        lux.setText("Luce : Elaborazione..");

                        TextView disp  = findViewById(R.id.disp1);
                        disp.setText("Dispositivi Connessi: \nNessun dispositivo\n"+" ");

                        Button annullaB = (Button) findViewById(R.id.annullaBtn);
                        annullaB.setText(" ");
                        annullaB.setBackgroundColor(Color.parseColor("#FFFFFF"));



                        Button dispB = (Button) findViewById(R.id.dispBtn);
                        Button opBtn = (Button) findViewById(R.id.opBtn);


                        dispB.setText("+");
                        dispB.setBackgroundColor(Color.parseColor("#93D388"));

                        opBtn.setText("In Attesa");
                        opBtn.setBackgroundColor(Color.parseColor("#969696"));





                      //  Toast.makeText(monitoring.this, "Dispositivo Aggiunto. Connettere un dispositivo", Toast.LENGTH_SHORT).show();
                    }

                });

                builder.setNegativeButton("Annulla", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.dismiss();
                    }
                });


                AlertDialog alert = builder.create();
                alert.show();


            }
        });

        //fine bottone campo


        //BOTTONE DISPOSITIVO


        dispB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog dialog;
                AlertDialog.Builder builder = new AlertDialog.Builder(monitoring.this);

                TextView sens1 = new TextView(monitoring.this);
                sens1.setText("  - GOCCIOL_LOZANO\n");

                TextView sens2 = new TextView(monitoring.this);
                sens2.setText("  - SENSORE_MT1\n");




                LinearLayout layout = new LinearLayout(monitoring.this);
                layout.setOrientation(LinearLayout.VERTICAL);
                layout.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
                layout.addView(sens1);
                layout.addView(sens2);




                builder.setTitle("Aggiungi un dispositivo:");
                builder.setMessage(" Ricerca in corso..");
                builder.setView(layout);

                builder.setPositiveButton("Aggiungi", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.dismiss();
                        Toast.makeText(monitoring.this, "Dispositivo connesso con successo!", Toast.LENGTH_SHORT).show();
                    }
                    });

                builder.setNegativeButton("Annulla", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.dismiss();
                    }
                });



                AlertDialog alert = builder.create();
                alert.show();

            }
        });


    //FINE BOTTONE DISPOSITIVO

        //cancella campo

        noB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final TextView nome = (TextView) findViewById(R.id.nomeCampo);
                final TextView lux = (TextView) findViewById(R.id.luce);
                final TextView temp = (TextView) findViewById(R.id.temperatura);
                final TextView umid = (TextView) findViewById(R.id.umidità);
                final TextView dispositivi = (TextView) findViewById(R.id.disp1);
                final ImageView foto = (ImageView) findViewById(R.id.campIMG);
                final Button dispB = (Button) findViewById(R.id.dispBtn);
                final Button irriga = (Button) findViewById(R.id.opBtn);
                final ImageView tempimg = (ImageView) findViewById(R.id.tempImg);
                final Button annullaB = (Button) findViewById(R.id.annullaBtn);



                //final Button fourth = (Button) findViewById(R.id.fourthButton);




                AlertDialog dialog;
                AlertDialog.Builder builder = new AlertDialog.Builder(monitoring.this);

                builder.setTitle("Elimina Campo");
                builder.setMessage("Sei sicuro di voler rimuovere il campo?");


                builder.setPositiveButton("Si", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        annullaB.setText("");
                        annullaB.setBackgroundColor(Color.parseColor("#FFFFFF"));
                        nome.setText(" ");
                        lux.setText(" ");
                        temp.setText(" ");
                        umid.setText(" ");
                        dispositivi.setText(" ");
                        foto.setImageResource(R.drawable.empty);
                        dispB.setBackgroundColor(Color.parseColor("#FFFFFF"));
                        dispB.setText(" ");
                        irriga.setBackgroundColor(Color.parseColor("#FFFFFF"));
                        irriga.setText(" ");
                        tempimg.setImageResource(R.drawable.empty);

                       // fourth.setBackgroundColor(Color.parseColor("##D2D2D2"));

                        Toast.makeText(monitoring.this, "Campo cancellato!", Toast.LENGTH_SHORT).show();

                    }
                });

                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.dismiss();
                    }
                });


                AlertDialog alert = builder.create();
                alert.show();

            }
        });

        //fine cancella campo

        Button first = (Button) findViewById(R.id.firstButton);
        Button second = (Button) findViewById(R.id.secondButton);
        Button third = (Button) findViewById(R.id.thirdButton);


        ConstraintLayout cos = findViewById(R.id.editCos);
        first.setOnClickListener(new View.OnClickListener() {
                                     @Override
                                     public void onClick(View v) {

                                         TextView text1 = findViewById(R.id.nomeCampo);
                                         text1.setText("Pomodori");

                                         ImageView image = (ImageView) findViewById(R.id.campIMG);
                                         image.setImageResource(R.drawable.pomodori);

                                         TextView temp = findViewById(R.id.temperatura);
                                         temp.setText("Temperatura : 26°C");

                                         TextView umidity = findViewById(R.id.umidità);
                                         umidity.setText("Umidità : 30%");

                                         TextView lux = findViewById(R.id.luce);
                                         lux.setText("Luce : Normale");

                                         TextView disp = findViewById(R.id.disp1);
                                         disp.setText("Dispositivi Connessi: \n- Gocciolatore \n- Sensore terreno");

                                         Button dispB = (Button) findViewById(R.id.dispBtn);
                                         final Button opBtn = (Button) findViewById(R.id.opBtn);

                                         ImageView tempimg = (ImageView) findViewById(R.id.tempImg);
                                         tempimg.setImageResource(R.drawable.temp1);

                                         opBtn.setText("IRRIGA ORA");
                                         dispB.setText("+");

                                          Button annullaB = (Button) findViewById(R.id.annullaBtn);
                                         annullaB.setText("Interrompi");
                                         annullaB.setBackgroundColor(Color.parseColor("#F86767"));



                                         dispB.setBackgroundColor(Color.parseColor("#93D388"));
                                         opBtn.setBackgroundColor(Color.parseColor("#88EC8C"));

                                         annullaB.setOnClickListener(new View.OnClickListener() {
                                             @Override
                                             public void onClick(View v) {


                                                 Toast.makeText(monitoring.this, "Irrigazione interrotta", Toast.LENGTH_SHORT).show();

                                             }
                                         });

                                         opBtn.setOnClickListener(new View.OnClickListener() {
                                             @Override
                                             public void onClick(View v) {
                                                 Toast.makeText(monitoring.this, "Irrigazione iniziata!", Toast.LENGTH_SHORT).show();
                                         };
                                         });


                                         tempimg.setOnClickListener(new View.OnClickListener() {
                                             @Override
                                             public void onClick(View v) {


                                                 Toast.makeText(monitoring.this, "Irrigazione Automatica Impostata", Toast.LENGTH_SHORT).show();

                                             }
                                         });
                                                  }
                                                         });


        second.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                TextView text1 = findViewById(R.id.nomeCampo);
                text1.setText("Insalata");

                ImageView image = (ImageView) findViewById(R.id.campIMG);
                image.setImageResource(R.drawable.insalate);

                TextView temp = findViewById(R.id.temperatura);
                temp.setText("Temperatura : 25°C");

                TextView umidity = findViewById(R.id.umidità);
                umidity.setText("Umidità : 30%");

                TextView lux  = findViewById(R.id.luce);
                lux.setText("Luce : Bassa");

                TextView disp  = findViewById(R.id.disp1);
                disp.setText("Dispositivi Connessi: \n- Gocciolatore \n- Sensore terreno");

                Button dispB = (Button) findViewById(R.id.dispBtn);
                Button opBtn = (Button) findViewById(R.id.opBtn);

                ImageView tempimg = (ImageView) findViewById(R.id.tempImg);
                tempimg.setImageResource(R.drawable.temp1);

                opBtn.setText("IRRIGA ORA");
                dispB.setText("+");

                Button annullaB = (Button) findViewById(R.id.annullaBtn);

                annullaB.setText("Interrompi");
                annullaB.setBackgroundColor(Color.parseColor("#F86767"));

                dispB.setBackgroundColor(Color.parseColor("#93D388"));
                opBtn.setBackgroundColor(Color.parseColor("#88EC8C"));

                annullaB.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {


                        Toast.makeText(monitoring.this, "Irrigazione interrotta", Toast.LENGTH_SHORT).show();

                    }
                });

                opBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {


                        Toast.makeText(monitoring.this, "Irrigazione iniziata!", Toast.LENGTH_SHORT).show();

                    }
                });

                tempimg.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {


                        Toast.makeText(monitoring.this, "Irrigazione Automatica Impostata", Toast.LENGTH_SHORT).show();

                    }
                });

            }
        });

        third.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                TextView text1 = findViewById(R.id.nomeCampo);
                text1.setText("Patate");

                ImageView image = (ImageView) findViewById(R.id.campIMG);
                image.setImageResource(R.drawable.patate);

                TextView temp = findViewById(R.id.temperatura);
                temp.setText("Temperatura : 27°C");

                TextView umidity = findViewById(R.id.umidità);
                umidity.setText("Umidità : 55%");

                TextView lux  = findViewById(R.id.luce);
                lux.setText("Luce : Normale");

                ImageView tempimg = (ImageView) findViewById(R.id.tempImg);
                tempimg.setImageResource(R.drawable.temp1);

                TextView disp  = findViewById(R.id.disp1);
                disp.setText("Dispositivi Connessi: \n- Gocciolatore \n- Sensore terreno");

                Button dispB = (Button) findViewById(R.id.dispBtn);
                Button opBtn = (Button) findViewById(R.id.opBtn);

                opBtn.setText("IRRIGA ORA");
                dispB.setText("+");

                Button annullaB = (Button) findViewById(R.id.annullaBtn);

                annullaB.setText("Interrompi");
                annullaB.setBackgroundColor(Color.parseColor("#F86767"));

                dispB.setBackgroundColor(Color.parseColor("#93D388"));
                opBtn.setBackgroundColor(Color.parseColor("#88EC8C"));

                annullaB.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {


                        Toast.makeText(monitoring.this, "Irrigazione interrotta", Toast.LENGTH_SHORT).show();

                    }
                });

                opBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {


                        Toast.makeText(monitoring.this, "Irrigazione iniziata!", Toast.LENGTH_SHORT).show();

                    }
                });

                tempimg.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {


                        Toast.makeText(monitoring.this, "Irrigazione Automatica Impostata", Toast.LENGTH_SHORT).show();

                    }
                });

            }
        });







        }




    public void openHome(){
        Intent intent = new Intent(this, home.class);
        startActivity(intent);
    }

    public void openSettings(){
        Intent intent = new Intent(this, settings.class);
        startActivity(intent);
    }

}