package com.example.esempio;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Layout;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import static android.text.TextUtils.isEmpty;

public class MainActivity extends AppCompatActivity {

    private ImageView button;

    private EditText idLog;
    private EditText passLog;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = (ImageView) findViewById(R.id.loginbutton);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                idLog = (EditText) findViewById(R.id.idbutton);
                passLog = (EditText) findViewById(R.id.passbutton);

                String strUserName = idLog.getText().toString();
                String strPassword = passLog.getText().toString();



                if (isEmpty(strUserName))
                    idLog.setError("ID errato");



                if (isEmpty(strPassword))
                    passLog.setError("Password errata");



                else openHome();


            }
        });




    }

    public void openHome(){

        Intent intent = new Intent(this, home.class);
        startActivity(intent);



    }
}