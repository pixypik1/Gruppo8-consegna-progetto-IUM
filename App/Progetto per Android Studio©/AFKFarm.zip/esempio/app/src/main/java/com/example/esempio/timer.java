package com.example.esempio;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

public class timer extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timer);
        //immagine "indietro"
        ImageView imageView = (ImageView) findViewById(R.id.returnImage);
        imageView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                onBackPressed();
            }
        });

        //immagine impostazioni
        ImageView settingsIMG = (ImageView) findViewById(R.id.settingsImage);
        settingsIMG.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                openSettings();
            }
        });

        Button newTimer = findViewById(R.id.newStock);
        Button noTimer = findViewById(R.id.noStock);

        TableLayout table = findViewById(R.id.tableLayout);


        newTimer.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {

                AlertDialog dialog;
                AlertDialog.Builder builder = new AlertDialog.Builder(timer.this);

                TextView mess1 = new TextView(timer.this);
                TextView mess2 = new TextView(timer.this);
                TextView mess3 = new TextView(timer.this);
                TextView mess4 = new TextView(timer.this);

                mess1.setTextSize(18);
                mess1.setText("  Campo:  ");
                mess2.setTextSize(18);
                mess2.setText("  Data: ");
                mess3.setTextSize(18);
                mess3.setText("  Ora: ");
                mess4.setTextSize(18);
                mess4.setText("  Durata (min.): ");

                final EditText input1 = new EditText(timer.this);
                final EditText input2 = new EditText(timer.this);
                final EditText input3 = new EditText(timer.this);
                final EditText input4 = new EditText(timer.this);


                LinearLayout layout = new LinearLayout(timer.this);
                layout.setOrientation(LinearLayout.VERTICAL);

                layout.addView(mess1);
                layout.addView(input1);
                layout.addView(mess2);
                layout.addView(input2);
                layout.addView(mess3);
                layout.addView(input3);
                layout.addView(mess4);
                layout.addView(input4);

                builder.setTitle("Nuovo Timer");
                builder.setMessage(" ");
                builder.setView(layout);

                builder.setPositiveButton("Aggiungi", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        TextView text1 = findViewById(R.id.a1);
                        text1.setText("#");

                        TextView text2 = findViewById(R.id.c1);
                        text2.setText(input1.getText().toString());

                        TextView text3 = findViewById(R.id.d1);
                        text3.setText(input2.getText().toString());

                        TextView text4 = findViewById(R.id.o1);
                        text4.setText(input3.getText().toString());

                        TextView text5 = findViewById(R.id.d2);
                        text5.setText(input4.getText().toString()+" min.");

                    }

                });

                builder.setNegativeButton("Annulla", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.dismiss();
                    }
                });


                AlertDialog alert = builder.create();
                alert.show();
            }
        });


        noTimer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                //cancellazione

                //popup
                final TextView a = findViewById(R.id.a1);
                final TextView ab = findViewById(R.id.a2);
                final TextView abc = findViewById(R.id.a3);

                AlertDialog dialog;
                AlertDialog.Builder builder = new AlertDialog.Builder(timer.this);


                builder.setTitle("Elimina Timer");
                builder.setMessage("Sei sicuro di voler rimuovere il timer per 'pomodori'?");

                //bottone si
                builder.setPositiveButton("Si", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        View row = (View) findViewById(R.id.row1);
                        ViewGroup container = ((ViewGroup) row.getParent());
                        container.removeView(row);
                        container.invalidate();
                        ab.setText("1");
                        abc.setText("2");

                        Toast.makeText(timer.this, "Timer cancellato", Toast.LENGTH_SHORT).show();

                    }
                });


                //bottone no
                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.dismiss();
                    }
                });
                AlertDialog alert = builder.create();
                alert.show();

            }
        });


    }



    public void openSettings(){
        Intent intent = new Intent(this, settings.class);
        startActivity(intent);
    }
    }
