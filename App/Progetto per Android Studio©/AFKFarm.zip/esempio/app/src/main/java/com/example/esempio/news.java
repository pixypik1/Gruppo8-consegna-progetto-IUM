package com.example.esempio;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class news extends AppCompatActivity {


ListView listView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);

        final TextView news1  = findViewById(R.id.news1);
        final TextView news2  = findViewById(R.id.news2);
        final TextView news3  = findViewById(R.id.news3);


    //immagine "indietro"
    ImageView imageView = (ImageView) findViewById(R.id.returnImage);
        imageView.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v)
        {
            openHome();
        }
    });

        //immagine impostazioni
        ImageView settingsIMG = (ImageView) findViewById(R.id.settingsImage);
        settingsIMG.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v)
            {
                openSettings();
            }
        });

            //bottone cancella tutto
        Button noNews = (Button) findViewById(R.id.noNewsButton);
        noNews.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v)
            {
               news1.setText("Nessuna nuova notifica");
                news2.setText("");
                news3.setText("");
                Toast.makeText(news.this, "Fatto!", Toast.LENGTH_SHORT).show();
            }
        });
}



    public void openHome(){
        Intent intent = new Intent(this, home.class);
        startActivity(intent);
    }

    public void openSettings(){
        Intent intent = new Intent(this, settings.class);
        startActivity(intent);
    }

    }
