package com.example.esempio;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class home extends AppCompatActivity {

    private Button logoutButton;
    private ImageView settings;
    private ImageView warehouse;
    private ImageView timer;
    private ImageView monitoring;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);


        //immagine impostazioni
        ImageView settingsIMG = (ImageView) findViewById(R.id.settingsImage);
        settingsIMG.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v)
            {
                openSettings();
            }
        });

        //immagine profilo
        ImageView imageView = (ImageView) findViewById(R.id.profileImage);
        imageView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v)
            {
                openProfile();
            }
        });

        // bottone notifiche

            settings = (ImageView)findViewById(R.id.newsButton);
            settings.setOnClickListener(new View.OnClickListener() {
                                            public void onClick(View v) {
                openNews();
             }
          });

        // bottone monitoraggio

            monitoring = (ImageView) findViewById(R.id.monitoringButton);
            monitoring.setOnClickListener(new View.OnClickListener() {
                                            public void onClick(View v) {
                openMonitoring();
            }
        });

        // bottone magazzino

            warehouse = (ImageView)findViewById(R.id.warehouseButton);
            warehouse.setOnClickListener(new View.OnClickListener() {
                                            public void onClick(View v) {
                openWarehouse();
            }
        });

        // bottone impostazioni

            timer = (ImageView)findViewById(R.id.timerButton);
            timer.setOnClickListener(new View.OnClickListener() {
                                            public void onClick(View v) {
                openTimer();
            }
        });

        //bottone logout

        ImageView profile = (ImageView) findViewById(R.id.profileImage);
        profile.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v)
            {
                openProfile();
            }
        });

        ImageView logoutSession = (ImageView) findViewById(R.id.logoutImage);
        logoutSession.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v)
            {
                openLogin();
            }
        });
    }


    public void openLogin(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void openNews(){
        Intent intent = new Intent(this, news.class);
        startActivity(intent);
    }

    public void openProfile(){
        Intent intent = new Intent(this, profile.class);
        startActivity(intent);
    }

    public void openSettings(){
        Intent intent = new Intent(this, settings.class);
        startActivity(intent);
    }

    public void openMonitoring(){
        Intent intent = new Intent(this, monitoring.class);
        startActivity(intent);
    }

    public void openTimer(){
        Intent intent = new Intent(this, timer.class);
        startActivity(intent);
    }
    public void openWarehouse(){
        Intent intent = new Intent(this, warehouse.class);
        startActivity(intent);
    }



}
