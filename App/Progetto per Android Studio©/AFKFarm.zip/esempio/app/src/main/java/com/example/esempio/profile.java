package com.example.esempio;

        import androidx.appcompat.app.AppCompatActivity;

        import android.os.Bundle;
        import android.view.View;
        import android.widget.ImageView;

public class profile extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        //immagine "indietro"
        ImageView imageView = (ImageView) findViewById(R.id.backButton);
        imageView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v)
            {
                onBackPressed();
            }
        });





    }
}