package com.example.esempio;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

public class warehouse extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_warehouse);


        //immagine "indietro"
        ImageView imageView = (ImageView) findViewById(R.id.returnImage);
        imageView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                openHome();
            }
        });

        //immagine impostazioni
        ImageView settingsIMG = (ImageView) findViewById(R.id.settingsImage);
        settingsIMG.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                openSettings();
            }
        });




        final TableLayout table = (TableLayout) findViewById(R.id.tableLayout);


        Button newStock = (Button) findViewById(R.id.newStock);
        Button noStock = (Button) findViewById(R.id.noStock);






        newStock.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                AlertDialog dialog;
                AlertDialog.Builder builder = new AlertDialog.Builder(warehouse.this);

                TextView mess1= new TextView(warehouse.this);
                TextView mess2= new TextView(warehouse.this);
                TextView mess3= new TextView(warehouse.this);

                mess1.setTextSize(18);
                mess1.setText("  Nome campo: ");
                mess2.setTextSize(18);
                mess2.setText("  Quantità: ");
                mess3.setTextSize(18);
                mess3.setText("  Data stockaggio: ");

                final EditText input1 = new EditText(warehouse.this);
                final EditText input2 = new EditText(warehouse.this);
                final EditText input3 = new EditText(warehouse.this);


                LinearLayout layout = new LinearLayout(warehouse.this);
                layout.setOrientation(LinearLayout.VERTICAL);

                layout.addView(mess1);
                layout.addView(input1);
                layout.addView(mess2);
                layout.addView(input2);
                layout.addView(mess3);
                layout.addView(input3);

                builder.setTitle("Nuovo Stock");
                builder.setMessage(" ");
                builder.setView(layout);

                builder.setPositiveButton("Aggiungi", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        TextView text1 = findViewById(R.id.a4);
                        text1.setText("#");

                        TextView text2 = findViewById(R.id.c1);
                        text2.setText(input1.getText().toString());

                        TextView text3 = findViewById(R.id.q1);
                        text3.setText(input2.getText().toString());

                        TextView text4 = findViewById(R.id.d1);
                        text4.setText(input3.getText().toString());

                        TextView text5 = findViewById(R.id.q2);
                        text5.setText("/");

                    }

                });

                builder.setNegativeButton("Annulla", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.dismiss();
                    }
                });


                AlertDialog alert = builder.create();
                alert.show();
            }
        });












        noStock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {







                //cancellazione

        //popup
                final TextView a = findViewById(R.id.a1);
                final TextView ab = findViewById(R.id.a2);
                final TextView abc = findViewById(R.id.a3);

                AlertDialog dialog;
                AlertDialog.Builder builder = new AlertDialog.Builder(warehouse.this);


                builder.setTitle("Elimina Stock");
                builder.setMessage("Sei sicuro di voler rimuovere lo stock 'Pomodori'?");

                        //bottone si
                builder.setPositiveButton("Si", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        View row = (View) findViewById(R.id.row1);
                        ViewGroup container = ((ViewGroup)row.getParent());
                            container.removeView(row);
                            container.invalidate();
                            ab.setText("1");
                            abc.setText("2");

                        Toast.makeText(warehouse.this, "Stock cancellato", Toast.LENGTH_SHORT).show();

                    }
                });


                        //bottone no
                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.dismiss();
                    }
                });
                AlertDialog alert = builder.create();
                alert.show();

            }
        });
    }








    public void openHome(){
        Intent intent = new Intent(this, home.class);
        startActivity(intent);

    }


    public void openSettings(){
        Intent intent = new Intent(this, settings.class);
        startActivity(intent);
    }
}
