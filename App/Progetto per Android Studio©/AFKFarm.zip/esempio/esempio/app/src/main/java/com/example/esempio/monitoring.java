package com.example.esempio;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class monitoring extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_monitoring);

        //immagine "indietro"
        ImageView imageView = (ImageView) findViewById(R.id.returnImage);
        imageView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v)
            {
                openHome();
            }
        });

        ImageView settingsIMG = (ImageView) findViewById(R.id.settingsImage);
        settingsIMG.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v)
            {
                openSettings();
            }
        });
    }

    public void openHome(){
        Intent intent = new Intent(this, home.class);
        startActivity(intent);
    }

    public void openSettings(){
        Intent intent = new Intent(this, settings.class);
        startActivity(intent);
    }

}