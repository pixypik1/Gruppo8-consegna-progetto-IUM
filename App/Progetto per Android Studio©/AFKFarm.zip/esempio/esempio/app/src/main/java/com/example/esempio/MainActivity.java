package com.example.esempio;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Layout;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.PopupWindow;

public class MainActivity extends AppCompatActivity {

    private Button button;




    // PROVA POPUP



    //FINE PROVA



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = (Button) findViewById(R.id.loginbutton);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openHome();
            }
        });


        View profileView = findViewById(R.id.forgotText);

        profileView.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                openHome();
            }
        });
    }

    public void openHome(){
        Intent intent = new Intent(this, home.class);
        startActivity(intent);


    }
}